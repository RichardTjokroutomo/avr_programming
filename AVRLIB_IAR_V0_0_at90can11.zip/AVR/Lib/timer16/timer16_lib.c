PWM

... PC FC ...

... PC ...



CAPTURE


TIMED



CLOCK

PWM_init(frequency)
{

}

PWMA_set(valueA)

PWMB_set(valueB)

PWMC_set(valueC)
